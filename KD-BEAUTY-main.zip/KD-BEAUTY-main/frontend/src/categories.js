const categories = [
    {
        name: "Makeup",
        img: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fG1ha2V1cHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    },
    {
        name: "Skincare",
        img: "https://images.unsplash.com/photo-1576426863848-c21f53c60b19?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fHNraW5jYXJlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60",
    },

    {   name: "Makeuptools",
        img: "https://images.unsplash.com/photo-1600228390270-970186129936?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8bWFrZXVwJTIwdG9vbHN8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60" },
];


export default categories;